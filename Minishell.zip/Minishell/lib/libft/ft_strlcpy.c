/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zelkalai <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/07 14:23:01 by zelkalai          #+#    #+#             */
/*   Updated: 2023/11/14 16:58:56 by zelkalai         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

size_t	ft_strlcpy(char **dest, const char *src, size_t dstsize)
{
	size_t	i;

	i = 0;
	if (dstsize == 0)
		return (ft_strlen(src));
  *dest = (char *)malloc(sizeof(char) * dstsize);
	while (i < dstsize - 1 && src[i] != '\0')
	{
		dest[0][i] = src[i];
		i++;
	}
	dest[0][i] = '\0';
	return (ft_strlen(src));
}
