/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exuc.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayel-mou <ayel-mou@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/01 17:45:11 by ayel-mou          #+#    #+#             */
/*   Updated: 2024/10/09 10:11:31 by ayel-mou         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef EXUC_H
# define EXUC_H

# include <dirent.h>
# include <minishell.h>
# include <sys/stat.h>
# include <sys/types.h>

extern int		g_exit_status;

# define P_DNIED 126
# define SUCCESS 0
# define ERROR_C 127
# define CMD_NOT_FOUND 127
# define GREEN "\033[1;32m"
# define RED "\033[1;31m"
# define YELLOW "\033[1;33m"
# define BLUE "\033[1;34m"
# define MAGENTA "\033[1;35m"
# define CYAN "\033[1;36m"
# define WHITE "\033[1;37m"
# define BLACK "\033[0;30m"
# define MAX_PATH 4096
# define M_SHELL "\033[1;31mminishell: \033[0m"
# define BEFORE 888
# define PARENT 777
# define CHILD 666
# define IN_HERE_DOC 555

char			*get_path(t_helper *help, t_list *list);
int				find_command(t_tree *root, t_helper *helper);
char			**get_options(t_helper *helper, t_list *list);
void			free_array(char **arr);
int				command_not_found(char *cmd);
int				get_exec_access(char *filename);
int				is_dir(char *dir);
int				ft_env(t_list *list, char **env);
int				ft_pwd(t_list *list, t_helper *helper);
int				is_builtins(t_tree *root);
int				run_builtins(t_tree *root, t_helper *helper);
int				ft_cd(t_list *list, t_helper *helper);
unsigned char	ft_exit(t_tree *root, t_helper *helper);
int				redirect_output(t_tree *root, t_helper *helper);
int				execute(t_tree *root, t_helper *helper);
int				count_arg(t_list *list);
int				redirect_input(t_tree *root, t_helper *helper);
int				execute_pipe(t_tree *root, t_helper *helper);
int				ft_echo(t_list *list);
int				check_and_or(t_tree *root, t_helper *helper);
void			my_free(t_helper *helper);
void			free_list(t_list *list);
int				ft_unset(t_list *list, t_helper *helper);
void			ctr_c(int sig);
void			signal_handeler(int place);
int				check_cmd(char *cmd, char *s, char **arg);
int				is_only_bs(t_tree *root);
int				is_only_slashes(t_tree *root);
void			handle_cd_error(const char *path, int error_type);
char			*get_target_path(t_list *list, t_helper *helper);
int				errors(char *file, int status, int fd);
int				prepare_command(t_tree *root, t_helper *helper);
void			check_signal(void);
int				has_slash(char *str);
int				check_write_and_dir(char *file);
int				check_read(char *file);
int				check_permission(char *file);
int				check_existence(char *file, int flag);
int				get_permission(char *file);
int				check_failure(char *file);

#endif
